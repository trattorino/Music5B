package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
 Button bottone;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         bottone = (Button)findViewById(R.id.button);
        Object btnAvvia;
        btnAvvia.setOnclickListener(new View.OnClickListener(){
            
                                    }





        )
    }
}
